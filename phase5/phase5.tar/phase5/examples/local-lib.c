/*
 * This file will not be run through your compiler.
 */

# include <stdio.h>

void print(int a, int b, int c)
{
    printf("%d %d %d\n", a, b, c);
}
