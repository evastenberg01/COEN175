#ifndef GENERATOR_H
#define GENERATOR_H

#include "Tree.h"
#include <iostream>

void generateGlobals(Scope *scope);

#endif