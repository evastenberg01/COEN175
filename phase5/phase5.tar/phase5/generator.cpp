#include "Tree.h"
#include "generator.h"
#include "Type.h"
#include <iostream>
#include <cassert>


using namespace std;
int caller_size = 0;

static const string registers[] = {
    "%edi", "%esi", "%edx", "%ecx", "%r8d", "%r9d"
};

static ostream &operator <<(ostream &ostr, Expression *expr) {
  expr->operand(ostr);
  return ostr;
}

void Block::generate() {
  for (auto stmt:_stmts)
    stmt->generate();
}

void Simple::generate() {
  _expr->generate();
}

void Expression::operand(ostream &ostr) 
{
}

void Number::operand(ostream &ostr) {
  ostr << "$" << _value;
}

void Identifier::operand(ostream &ostr) {
  int offset = _symbol->_offset;
  if(offset==0) {
    cout << _symbol->name();
  }
  else {
    cout << offset << "(%rbp)";
  }
}

void generateGlobals(Scope *scope) {
  Symbols symbols = scope->symbols();
  for (auto symbol:symbols) {
    if (!symbol->type().isFunction() && !symbol->type().isError())
      cout << ".comm " << symbol->name() << ", " << symbol->type().size() << endl;
  }
}

void Function::generate() {

  const Symbols &symbols = _body->declarations()->symbols();
  unsigned long i;
  int offsetCounter = 0;
  //allocate offset
  for( i = 0; i < symbols.size(); i++) {
    offsetCounter -= symbols[i]->type().size();
    symbols[i]->_offset = offsetCounter;
  }
  //make sure stack is 16 bit aligned
  if(offsetCounter %16 >=0) 
    offsetCounter -= (offsetCounter%16);
  else
    offsetCounter -= 16 + (offsetCounter%16);

  cout << ".globl\t" << _id->name() << endl;
  cout << _id->name() << ": " << endl;
  
  //prologue
  cout << "\tpushq\t%rbp" << endl;
	cout << "\tmovq\t%rsp, %rbp" << endl;
	cout << "\tsubq\t" << "$" << -(offsetCounter) << ", %rsp" << endl;

  //spill
  for(i = 0; i < _id->type().parameters()->size(); i++) {
    cout << "\tmovl\t " << registers[i] << ", " << symbols[i]->_offset << "(%rbp)" << endl;
  }

  _body->generate();

  //epilogue
  cout << "\tmovq\t%rbp,\t%rsp" << endl;
	cout << "\tpopq\t%rbp" << endl;
	cout << "\tret" << endl;
}

void Assignment::generate() {
  cout << "\tmovl " << _right << ", " << _left << endl;
}

void Call::generate() {
  unsigned i;
  for(i = 0; i < _args.size(); i++) 
    cout << "\tmovl\t" << _args[i] << ",\t" << registers[i] << endl;
  cout << "\tcall\t" << _id->name() << endl;

}